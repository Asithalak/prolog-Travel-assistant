% DISTRICTS

% Western Province
place(colombo, galle_face_green).
place(colombo, beira_lake).
place(colombo, gangaramaya_temple).
place(colombo, independence_square).
place(colombo, colombo_national_museum).
place(colombo, viharamahadevi_park).
place(colombo, dutch_hospital_shopping_precinct).
place(colombo, pettah_floating_market).
place(gampaha, negombo_beach).
place(gampaha, negombo_lagoon).
place(gampaha, henerathgoda_botanic_garden).
place(kalutara, kalutara_temple).
place(kalutara, kalutara_bodhiya).
place(kalutara, kalido_beach).
place(kalutara, richmond_castle).
place(kalutara, bentota_beach).

% Central Province
place(kandy, temple_of_the_tooth).
place(kandy, temple_of_the_sacred_tooth_relic).
place(kandy, udawattekele_sanctuary).
place(kandy, bahirawakanda_buddha_statue).
place(kandy, peradeniya_botanic_gardens).
place(kandy, kandy_lake).
place(kandy, bahiravokanda_vihara_buddha_statue).
place(kandy, pinnawala_elephant_orphanage).
place(matale, dambulla_cave_temple).
place(matale, knuckles_mountain_range).
place(matale, spice_gardens).
place(nuwara_eliya, gregory_lake).
place(nuwara_eliya, hakgala_botanical_garden).
place(nuwara_eliya, ambewela_farm).
place(nuwara_eliya, lovers_leap_waterfall).
place(nuwara_eliya, moon_plains).
place(nuwara_eliya, nuwara_eliya_town).
place(nuwara_eliya, horton_plains_national_park).
place(nuwara_eliya, tea_plantations).

% Southern Province
place(galle, galle_fort).
place(galle, japanese_peace_pagoda).
place(galle, mihiripenna_beach).
place(galle, jungle_beach).
place(galle, unawatuna_beach).
place(matara, polhena_beach).
place(matara, weherahena_temple).
place(matara, star_fort).
place(matara, matara_fort).
place(hambantota, yala_national_park).
place(hambantota, ridiyagama_safari_park).
place(hambantota, bundala_national_park).
place(hambantota, udawalawe_national_park).

% Northern Province
place(jaffna, nallur_temple).
place(jaffna, nallur_kandaswamy_temple).
place(jaffna, nagadeepa_temple).
place(jaffna, casuarina_beach).
place(jaffna, delft_island).
place(jaffna, jaffna_fort).
place(jaffna, jaffna_library).
place(kilinochchi, elephant_pass).
place(mannar, adam_bridge).
place(vavuniya, archaeological_museum).
place(mullaitivu, naiyaru_beach).

% Eastern Province
place(batticaloa, kallar_lagoon).
place(batticaloa, kovilady_beach).
place(batticaloa, batticaloa_lighthouse).
place(batticaloa, pasikuda_beach).
place(ampara, arugam_bay).
place(ampara, galoya_national_park).
place(ampara, senanayake_samudraya).
place(ampara, kumana_national_park).
place(trincomalee, nilaveli_beach).
place(trincomalee, koneswaram_temple).
place(trincomalee, fort_frederick).
place(trincomalee, marble_beach).
place(trincomalee, nilaveli_and_uppuveli_beaches).

% North Western Province
place(kurunegala, athaagala_rock).
place(kurunegala, ridi_viharaya).
place(kurunegala, ethagala_elephant_rock).
place(puttalam, wilpattu_park).
place(puttalam, kalpitiya_beach).
place(puttalam, kalpitiya).

% North Central Province
place(anuradhapura, sri_maha_bodhiya).
place(anuradhapura, mirisawetiya_stupa).
place(anuradhapura, twin_ponds).
place(anuradhapura, ancient_city_of_anuradhapura).
place(anuradhapura, mihintale).
place(anuradhapura, wilpattu_national_park).
place(polonnaruwa, king_parakramabahu_statue).
place(polonnaruwa, vatadageya).
place(polonnaruwa, gal_viharaya).
place(polonnaruwa, ancient_city_of_polonnaruwa).

% Uva Province
place(badulla, nine_arch_bridge).
place(badulla, bogoda_wooden_bridge).
place(badulla, dunhinda_falls).
place(badulla, ella).
place(badulla, little_adams_peak).
place(badulla, ravana_falls).
place(monaragala, ella_rock).
place(monaragala, galabedda_cave_temple).
place(monaragala, diyaluma_falls).
place(monaragala, buduruwagala).

% Sabaragamuwa Province
place(ratnapura, gem_museum).
place(ratnapura, batuwita_ella).
place(ratnapura, sinharaja_forest_reserve).
place(ratnapura, ratnapura).
place(ratnapura, adams_peak_sri_pada).
place(kegalle, pinnawala_elephant_orphanage).
place(kegalle, dehiowita_forest_reserve).
place(kegalle, asupini_ella).
place(kegalle, elephant_freedom_project).
place(kegalle, kitulgala).

% ACTIVITIES 

activity(colombo, shopping).
activity(colombo, cultural_event).
activity(colombo, temple_visits).
activity(gampaha, boat_ride).
activity(gampaha, shopping).
activity(gampaha, temple_visits).
activity(kalutara, beach_activities).
activity(kalutara, shopping).
activity(kalutara, temple_visits).

activity(kandy, cultural_events).
activity(kandy, temple_visits).
activity(kandy, shopping).
activity(kandy, hiking).
activity(matale, temple_visits).
activity(matale, cultural_event).
activity(matale, hiking).
activity(nuwara_eliya, hiking).
activity(nuwara_eliya, garden_visits).

activity(galle, beach_activities).
activity(galle, shopping).
activity(galle, temple_visits).
activity(matara, beach_activities).
activity(matara, temple_visits).
activity(hambantota, safari).
activity(hambantota, cultural_event).

activity(jaffna, temple_visits).
activity(jaffna, cultural_events).
activity(mannar, temple_visits).
activity(vavuniya, temple_visits).
activity(vavuniya, safari).
activity(mullaitivu, beach_activities).

activity(batticaloa, beach_activities).
activity(batticaloa, temple_visits).
activity(ampara, beach_activities).
activity(ampara, safari).
activity(trincomalee, beach_activities).
activity(trincomalee, temple_visits).

activity(kurunegala, hiking).
activity(kurunegala, temple_visits).
activity(puttalam, safari).
activity(puttalam, beach_activities).

activity(anuradhapura, temple_visits).
activity(anuradhapura, cultural_event).
activity(anuradhapura, safari).
activity(polonnaruwa, temple_visits).
activity(polonnaruwa, cultural_event).
activity(polonnaruwa, safari).

activity(badulla, hiking).
activity(badulla, temple_visits).
activity(monaragala, hiking).
activity(monaragala, temple_visits).

activity(ratnapura, hiking).
activity(ratnapura, temple_visits).
activity(kegalle, temple_visits).
activity(kegalle, hiking).

%  CUISINES 

cuisine(colombo, street_food).
cuisine(colombo, rice_and_curry).
cuisine(colombo, seafood).
cuisine(gampaha, seafood).
cuisine(gampaha, rice_and_curry).
cuisine(kalutara, seafood).
cuisine(kalutara, rice_and_curry).

cuisine(kandy, traditional_sweets).
cuisine(kandy, rice_and_curry).
cuisine(matale, rice_and_curry).
cuisine(nuwara_eliya, traditional_sweets).
cuisine(nuwara_eliya, rice_and_curry).

cuisine(galle, seafood).
cuisine(galle, traditional_sweets).
cuisine(galle, rice_and_curry).
cuisine(matara, buffalo_curd).
cuisine(matara, seafood).
cuisine(hambantota, buffalo_curd).
cuisine(hambantota, seafood).

cuisine(jaffna, seafood).
cuisine(jaffna, traditional_sweets).
cuisine(kilinochchi,buffalo_curd).
cuisine(kilinochchi, rice_and_curry).
cuisine(mannar, seafood).
cuisine(vavuniya, traditional_sweets).
cuisine(mullaitivu, seafood).

cuisine(batticaloa, seafood).
cuisine(batticaloa, rice_and_curry).
cuisine(ampara, rice_and_curry).
cuisine(ampara, traditional_sweets).
cuisine(trincomalee, seafood).

cuisine(kurunegala, rice_and_curry).
cuisine(kurunegala, traditional_sweets).
cuisine(puttalam, seafood).
cuisine(puttalam, rice_and_curry).

cuisine(anuradhapura, rice_and_curry).
cuisine(anuradhapura, traditional_sweets).
cuisine(anuradhapura, buffalo_curd).
cuisine(polonnaruwa, rice_and_curry).
cuisine(polonnaruwa, buffalo_curd).

cuisine(badulla, traditional_sweets).
cuisine(badulla, rice_and_curry).
cuisine(monaragala, buffalo_curd).
cuisine(monaragala, traditional_sweets).

cuisine(ratnapura, rice_and_curry).
cuisine(ratnapura, traditional_sweets).
cuisine(kegalle, traditional_sweets).
cuisine(kegalle, rice_and_curry).

% BEST SEASONS

season(colombo, dec_to_feb).        
season(gampaha, dec_to_feb).        
season(kalutara, dec_to_feb).       
season(kandy, dec_to_feb).         
season(matale, feb_to_may).         
season(nuwara_eliya, feb_to_may).   
season(galle, feb_to_may).          
season(matara, feb_to_may).         
season(hambantota, may_to_sep).     
season(jaffna, may_to_sep).         
season(kilinochchi, may_to_sep).    
season(mannar, may_to_sep).         
season(vavuniya, may_to_sep).      
season(mullaitivu, may_to_sep).     
season(batticaloa, may_to_sep).     
season(ampara, may_to_sep).         
season(trincomalee, may_to_sep).    
season(kurunegala, sep_to_dec).     
season(puttalam, sep_to_dec).      
season(anuradhapura, sep_to_dec).   
season(polonnaruwa, sep_to_dec).    
season(badulla, sep_to_dec).        
season(monaragala, sep_to_dec).     
season(ratnapura, dec_to_feb).      
season(kegalle, dec_to_feb).        

%  RULES

show_details(District) :-
    findall(Place, place(District, Place), PlaceList),
    findall(Activity, activity(District, Activity), ActivityList),
    findall(Food, cuisine(District, Food), FoodList),
    season(District, Season),
    format("~n* District: ~w~n~n", [District]),
    format("* Places to Visit: ~w~n", [PlaceList]),
    format("* Activities: ~w~n", [ActivityList]),
    format("* Foods to Try: ~w~n", [FoodList]),
    format("* Best Season: ~w~n", [Season]).

show_suggested_details([]).
show_suggested_details([D|Rest]) :-
    show_details(D), nl, show_suggested_details(Rest).

% ---------- INTERACTIVE TRAVEL ASSISTANT ----------
start :-
    write('Welcome to the Sri Lanka Travel Assistant!'), nl,

    % Step 1: Choose Season
    write('Select your preferred travel season:'), nl,
    write('1. dec_to_feb'), nl,
    write('2. feb_to_may'), nl,
    write('3. may_to_sep'), nl,
    write('4. sep_to_dec'), nl,
    write('Enter your choice (1-4): '), read(SChoice),
    get_season(SChoice, Season),

    % Step 2: Choose Activity
    write('Select your preferred activity:'), nl,
    write('1. beach_activities'), nl,
    write('2. temple_visits'), nl,
    write('3. shopping'), nl,
    write('4. safari'), nl,
    write('5. hiking'), nl,
    write('Enter your choice (1-5): '), read(AChoice),
    get_activity(AChoice, ActivityPref),

    % Step 3: Choose Food
    write('Select your preferred food type:'), nl,
    write('1. rice_and_curry'), nl,
    write('2. seafood'), nl,
    write('3. street_food'), nl,
    write('4. traditional_sweets'), nl,
    write('5. buffalo_curd'), nl,
    write('Enter your choice (1-5): '), read(FChoice),
    get_food(FChoice, FoodPref),

    % Step 4: Matching
    findall(District, (season(District, Season), activity(District, ActivityPref), cuisine(District, FoodPref)), DistrictList),

    ( DistrictList = [] ->
        nl, write('Sorry, no districts match your preferences exactly. Try relaxing some preferences.'), nl
    ;
        nl, format('Based on your preferences, you may like these districts: ~w~n', [DistrictList]),
        show_suggested_details(DistrictList)
    ).

% ---------- MAPPINGS ----------
get_season(1, dec_to_feb).
get_season(2, feb_to_may).
get_season(3, may_to_sep).
get_season(4, sep_to_dec).

get_activity(1, beach_activities).
get_activity(2, temple_visits).
get_activity(3, shopping).
get_activity(4, safari).
get_activity(5, hiking).

get_food(1, rice_and_curry).
get_food(2, seafood).
get_food(3, street_food).
get_food(4, traditional_sweets).
get_food(5, buffalo_curd).
